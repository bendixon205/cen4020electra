﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SQLite;


public partial class _Default : Page
{
    int count = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        LoadGrid();
    }

    public void LoadGrid()
    {
        GridView1.DataSource = loadDataTable("carinv");
        GridView1.DataBind();
    }

    public void Clear()
    {
        txtID.Text = "ID";
        txtModel.Text = "Model";
        txtYear.Text = "Year";
        txtColor.Text = "Color";
        txtEngine.Text = "Engine";
        txtMPG.Text = "MPG";
        txtInterior.Text = "Interior";
        txtHandling.Text = "Handling";
        txtControls.Text = "Controls";
        txtSafety.Text = "Safety";
        txtAudio.Text = "Audio";
        txtConvenience.Text = "Convenience";
        txtMaintenance.Text = "Maintenance";
        txtWarranty.Text = "Warranty";
        txtPackage.Text = "Package";
        txtCustomer.Text = "Customer";
        txtStatus.Text = "Status";
        txtDelivered.Text = "Delivered";
        txtNumberMaint.Text = "Number of Maint.";
        txtNextMaint.Text = "Next Maint.";
        txtLastMaint.Text = "Last Maint.";

        lblMessage.Visible = false;
    }

    

    //Image Buttons
    protected void imgHome_Click(object sender, ImageClickEventArgs e)
    {
        PanelHomeHeader.Visible = true;
        PanelHomeBody.Visible = true;
        PanelBody.Visible = false;
        PanelHomeFooter.Visible = false;
        PanelMessage.Visible = false;
        PanelFields.Visible = false;
        PanelGrid.Visible = false;
        Clear();
    }

    protected void imgSearch_Click(object sender, ImageClickEventArgs e)
    {
        PanelHomeHeader.Visible = true;
        PanelHomeBody.Visible = false;
        PanelBody.Visible = true;
        PanelHomeFooter.Visible = false;
        PanelMessage.Visible = false;
        PanelFields.Visible = true;
        PanelGrid.Visible = true;
        btnSearch.Visible = true;
        btnAdd.Visible = false;
        btnUpdate.Visible = false;
        btnDelete.Visible = false;
        Clear();
    }

    protected void imgAdd_Click(object sender, ImageClickEventArgs e)
    {
        PanelHomeHeader.Visible = true;
        PanelHomeBody.Visible = false;
        PanelBody.Visible = true;
        PanelHomeFooter.Visible = false;
        PanelMessage.Visible = false;
        PanelFields.Visible = true;
        PanelGrid.Visible = false;
        btnSearch.Visible = false;
        btnAdd.Visible = true;
        btnUpdate.Visible = false;
        btnDelete.Visible = false;
        Clear();
    }

    protected void imgUpdate_Click(object sender, ImageClickEventArgs e)
    {
        PanelHomeHeader.Visible = true;
        PanelHomeBody.Visible = false;
        PanelBody.Visible = true;
        PanelHomeFooter.Visible = false;
        PanelMessage.Visible = false;
        PanelFields.Visible = true;
        PanelGrid.Visible = false;
        btnSearch.Visible = false;
        btnAdd.Visible = false;
        btnUpdate.Visible = true;
        btnDelete.Visible = false;
        Clear();
    }

    protected void imgDelete_Click(object sender, ImageClickEventArgs e)
    {
        PanelHomeHeader.Visible = true;
        PanelHomeBody.Visible = false;
        PanelBody.Visible = true;
        PanelHomeFooter.Visible = false;
        PanelMessage.Visible = false;
        PanelFields.Visible = true;
        PanelGrid.Visible = false;
        btnSearch.Visible = false;
        btnAdd.Visible = false;
        btnUpdate.Visible = false;
        btnDelete.Visible = true;
        Clear();
    }


    //Buttons
    protected void btnClear_Click(object sender, EventArgs e)
    {
        Clear();
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        //loadDataTable();
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        //addDataTable();
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        updateDataTable();
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        deleteDataTable();
    }


    //SQL Functions
    public DataTable loadDataTable(string table)
    {
        DataTable dt = new DataTable();
        SQLiteConnection connection = new SQLiteConnection("Data Source=C:\\Users\\Andres\\Documents\\Visual Studio 2015\\Projects\\cen4020electra-master\\cardb.db;Version=3;");
        
        //Opens connection to database
        connection.Open();

        string sql = "SELECT * FROM carinv";

        //Creates SQL command using a string
        SQLiteCommand cmd = new SQLiteCommand(sql, connection);

        //Executes the string stored in the SQL command
        dt.Load(cmd.ExecuteReader());

        //Closes connectiont to database (REQUIRED TO DO THIS)
        connection.Close();
        return dt;
    }

    public void addDataTable(string model = " ", string year = " ", string color = " ", string engine = "0", string mpg = "0",
                                string handling = " ", string controls = " ", string safety = " ", string exterior = " ",
                                string interior = " ", string audio = " ", string convenience = " ", string maintprogram = " ",
                                string warranty = " ", string package = " ", string orderstatus = " ", string delivered = " ",
                                string lastmaint = " ", string nextmaint = " ", string amountofmaint = "0", string customer = " ")
    {
        //Creates a connection to the database
        SQLiteConnection connection = new SQLiteConnection("Data Source=c:\\Users\\Ben\\CEN4020\\cardb.db;Version=3;");
        //Opens connection to database
        connection.Open();

        //Stores SQL INSERT command into a string
        string sql = "Insert into carinv(id, model, year, color, engine, mpg, handling, controls, safety, exterior, interior, "
                    + "audio, convenience, maintprogram, warranty, package, orderstatus, delivered, lastmaint, nextmaint, amountofmaint, customer) "
                    + "values(NULL," + "'" + model + "'," + year + "," + "'" + color + "'," + engine + "," + mpg + ","
                    + "'" + handling + "'," + "'" + controls + "'," + "'" + safety + "'," + "'" + exterior + "'," + "'" + interior + "'," + "'" + audio + "',"
                    + "'" + convenience + "'," + "'" + maintprogram + "'," + "'" + warranty + "'," + "'" + package + "'," + "'" + orderstatus + "'," + "'" + delivered + "',"
                    + "'" + lastmaint + "'," + "'" + nextmaint + "'," + amountofmaint + ",'" + customer + "')";

        Console.WriteLine(sql); //Output to see if the string is correct INSERT command (Does not alter database)

        //Creates SQL command using a string
        SQLiteCommand cmd = new SQLiteCommand(sql, connection);

        //Executes the string stored in the SQL command
        cmd.ExecuteNonQuery();

        //Closes connectiont to database (REQUIRED TO DO THIS)
        connection.Close();
    }


    public void updateDataTable()
    {
        try
        {
            count = 0;
            string fields = "";

            fields = updateFields(txtModel.Text, "Model");
            fields = updateFields(txtYear.Text, "Year");
            fields = updateFields(txtColor.Text, "Color");
            fields = updateFields(txtEngine.Text, "Engine");
            fields = updateFields(txtMPG.Text, "MPG");
            fields = updateFields(txtInterior.Text, "Interior");
            fields = updateFields(txtHandling.Text, "Handling");
            fields = updateFields(txtControls.Text, "Controls");
            fields = updateFields(txtSafety.Text, "Safety");
            fields = updateFields(txtAudio.Text, "Audio");
            fields = updateFields(txtConvenience.Text, "Convenience");
            fields = updateFields(txtMaintenance.Text, "Maintenance");
            fields = updateFields(txtWarranty.Text, "Warranty");
            fields = updateFields(txtPackage.Text, "Package");
            fields = updateFields(txtCustomer.Text, "Customer");
            fields = updateFields(txtStatus.Text, "Status");
            fields = updateFields(txtDelivered.Text, "Delivered");
            fields = updateFields(txtModel.Text, "Number of Maint.");
            fields = updateFields(txtNextMaint.Text, "Next Maint.");
            fields = updateFields(txtLastMaint.Text, "Last Maint.");

            SQLiteConnection connection = new SQLiteConnection("Data Source=c:\\Users\\Ben\\CEN4020\\cardb.db;Version=3;");
            connection.Open();
            string sql = "Update carinv set " + fields + " where id = '" + txtID.Text + "'";
            SQLiteCommand cmd = new SQLiteCommand(sql, connection);
            cmd.ExecuteNonQuery();
            connection.Close();

            lblMessage.Text = "Record was updated successfully.";
            lblMessage.Visible = true;
            PanelMessage.Visible = true;
        }

        catch
        {
            lblMessage.Text = "Error: Record could not be updated.";
            lblMessage.Visible = true;
            PanelMessage.Visible = true;
        }
    }

    public string updateFields(string text, string original)
    {
        string where = "";

        if (text == original)
        {
            where += "";
        }
        else
        {
            if (count > 0)
            {
                where += ", ";
            }
            count++;
            where += " model = '" + txtModel.Text + "' ";
        }
        return where;
    }


    public void deleteDataTable()
    {
        try
        {
            count = 0;
            string where = "";

            where = deleteWhere(txtModel.Text, "Model");
            where = deleteWhere(txtYear.Text, "Year");
            where = deleteWhere(txtColor.Text, "Color");
            where = deleteWhere(txtEngine.Text, "Engine");
            where = deleteWhere(txtMPG.Text, "MPG");
            where = deleteWhere(txtInterior.Text, "Interior");
            where = deleteWhere(txtHandling.Text, "Handling");
            where = deleteWhere(txtControls.Text, "Controls");
            where = deleteWhere(txtSafety.Text, "Safety");
            where = deleteWhere(txtAudio.Text, "Audio");
            where = deleteWhere(txtConvenience.Text, "Convenience");
            where = deleteWhere(txtMaintenance.Text, "Maintenance");
            where = deleteWhere(txtWarranty.Text, "Warranty");
            where = deleteWhere(txtPackage.Text, "Package");
            where = deleteWhere(txtCustomer.Text, "Customer");
            where = deleteWhere(txtStatus.Text, "Status");
            where = deleteWhere(txtDelivered.Text, "Delivered");
            where = deleteWhere(txtModel.Text, "Number of Maint.");
            where = deleteWhere(txtNextMaint.Text, "Next Maint.");
            where = deleteWhere(txtLastMaint.Text, "Last Maint.");

            SQLiteConnection connection = new SQLiteConnection("Data Source=c:\\Users\\Ben\\CEN4020\\cardb.db;Version=3;");
            connection.Open();
            string sql = "Delete from carinv where " + where;
            SQLiteCommand cmd = new SQLiteCommand(sql, connection);
            cmd.ExecuteNonQuery();
            connection.Close();

            lblMessage.Text = "Record was deleted successfully.";
            lblMessage.Visible = true;
            PanelMessage.Visible = true;
        }

        catch
        {
            lblMessage.Text = "Error: Record could not be deleted.";
            lblMessage.Visible = true;
            PanelMessage.Visible = true;
        }
    }

    public string deleteWhere(string text, string original)
    {
        string where = "";

        if (text == original)
        {
            where += "";
        }
        else
        {
            if (count > 0)
            {
                where += " AND ";
            }
            count++;
            where += " model = '" + txtModel.Text + "' ";
        }
        return where;
    }

}
