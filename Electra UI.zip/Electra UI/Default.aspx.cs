﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SQLite;


public partial class _Default : Page
{
    int count = 0;
    string table = "carinv";

    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack) LoadGrid();
    }

    public void LoadGrid()
    {
        GridView1.DataSource = loadDataTable();
        GridView1.DataBind();
    }

    public Boolean validateFields()
    {
        try
        {
            int id = Int32.Parse(txtID.Text);
            if(id <= 0)
            {
                lblMessage.Text = "ID needs to be positive integer.";
                PanelMessage.Visible = true;
                return false;
            }
        }

        catch (FormatException id)
        {
            lblMessage.Text = "ID needs to be positive integer.";
            PanelMessage.Visible = true;
            return false;
        }
        return true;
    }

    public void Clear()
    {
        txtID.Text = "ID";
        txtModel.Text = "Model";
        txtYear.Text = "Year";
        txtColor.Text = "Color";
        txtEngine.Text = "Engine";
        txtMPG.Text = "MPG";
        txtInterior.Text = "Interior";
        txtHandling.Text = "Handling";
        txtControls.Text = "Controls";
        txtSafety.Text = "Safety";
        txtAudio.Text = "Audio";
        txtConvenience.Text = "Convenience";
        txtMaintenance.Text = "Maintenance";
        txtWarranty.Text = "Warranty";
        txtPackage.Text = "Package";
        txtCustomer.Text = "Customer";
        txtStatus.Text = "Status";
        txtDelivered.Text = "Delivered";
        txtNumberMaint.Text = "Number of Maint.";
        txtNextMaint.Text = "Next Maint.";
        txtLastMaint.Text = "Last Maint.";

        PanelMessage.Visible = false;
    }

    

    //Image Buttons
    protected void imgHome_Click(object sender, ImageClickEventArgs e)
    {
        PanelHomeHeader.Visible = true;
        PanelHomeBody.Visible = true;
        PanelBody.Visible = false;
        PanelHomeFooter.Visible = true;
        PanelMessage.Visible = false;
        PanelFields.Visible = false;
        PanelGrid.Visible = false;
        Clear();
    }

    protected void imgSearch_Click(object sender, ImageClickEventArgs e)
    {
        PanelHomeHeader.Visible = true;
        PanelHomeBody.Visible = false;
        PanelBody.Visible = true;
        PanelHomeFooter.Visible = true;
        PanelMessage.Visible = false;
        PanelFields.Visible = true;
        PanelGrid.Visible = true;
        btnSearch.Visible = true;
        btnAdd.Visible = false;
        btnUpdate.Visible = false;
        btnDelete.Visible = false;
        txtID.ReadOnly = false;
        Clear();
        LoadGrid();
    }

    protected void imgAdd_Click(object sender, ImageClickEventArgs e)
    {
        PanelHomeHeader.Visible = true;
        PanelHomeBody.Visible = false;
        PanelBody.Visible = true;
        PanelHomeFooter.Visible = true;
        PanelMessage.Visible = false;
        PanelFields.Visible = true;
        PanelGrid.Visible = false;
        btnSearch.Visible = false;
        btnAdd.Visible = true;
        btnUpdate.Visible = false;
        btnDelete.Visible = false;
        Clear();
        txtID.ReadOnly = true;
        LoadGrid();
    }

    protected void imgUpdate_Click(object sender, ImageClickEventArgs e)
    {
        PanelHomeHeader.Visible = true;
        PanelHomeBody.Visible = false;
        PanelBody.Visible = true;
        PanelHomeFooter.Visible = true;
        PanelMessage.Visible = false;
        PanelFields.Visible = true;
        PanelGrid.Visible = false;
        btnSearch.Visible = false;
        btnAdd.Visible = false;
        btnUpdate.Visible = true;
        btnDelete.Visible = false;
        txtID.ReadOnly = false;
        Clear();
        LoadGrid();
    }

    protected void imgDelete_Click(object sender, ImageClickEventArgs e)
    {
        PanelHomeHeader.Visible = true;
        PanelHomeBody.Visible = false;
        PanelBody.Visible = true;
        PanelHomeFooter.Visible = true;
        PanelMessage.Visible = false;
        PanelFields.Visible = true;
        PanelGrid.Visible = false;
        btnSearch.Visible = false;
        btnAdd.Visible = false;
        btnUpdate.Visible = false;
        btnDelete.Visible = true;
        txtID.ReadOnly = false;
        Clear();
        LoadGrid();
    }


    //Buttons
    protected void btnClear_Click(object sender, EventArgs e)
    {
        Clear();
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        loadDataTable();
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        addDataTable();
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        bool validated = validateFields();
        if (validated) updateDataTable();
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        bool validated = validateFields();
        if (validated) deleteDataTable();
    }


    //SQL Functions
    public DataTable loadDataTable()
    {
        DataTable dt = new DataTable();

        try
        {
            count = 0;
            string where = "";

            where += searchWhere(txtID.Text, "ID");
            where += searchWhere(txtModel.Text, "Model");
            where += searchWhere(txtYear.Text, "Year");
            where += searchWhere(txtColor.Text, "Color");
            where += searchWhere(txtEngine.Text, "Engine");
            where += searchWhere(txtMPG.Text, "MPG");
            where += searchWhere(txtInterior.Text, "Interior");
            where += searchWhere(txtHandling.Text, "Handling");
            where += searchWhere(txtControls.Text, "Controls");
            where += searchWhere(txtSafety.Text, "Safety");
            where += searchWhere(txtAudio.Text, "Audio");
            where += searchWhere(txtConvenience.Text, "Convenience");
            where += searchWhere(txtMaintenance.Text, "Maintenance", "maintprogram");
            where += searchWhere(txtWarranty.Text, "Warranty");
            where += searchWhere(txtPackage.Text, "Package");
            where += searchWhere(txtCustomer.Text, "Customer");
            where += searchWhere(txtStatus.Text, "Status", "orderstatus");
            where += searchWhere(txtDelivered.Text, "Delivered");
            where += searchWhere(txtNumberMaint.Text, "Number of Maint.", "amountofmaint");
            where += searchWhere(txtNextMaint.Text, "Next Maint.", "nextmaint");
            where += searchWhere(txtLastMaint.Text, "Last Maint.", "lastmaint");

            SQLiteConnection connection = new SQLiteConnection("Data Source=C:\\Users\\Andres\\Documents\\Visual Studio 2015\\Projects\\cen4020electra-master\\cardb.db;Version=3;");
            connection.Open();
            string sql = "SELECT * FROM " + table + " " + where;
            SQLiteCommand cmd = new SQLiteCommand(sql, connection);
            dt.Load(cmd.ExecuteReader());
            connection.Close();
        }

        catch
        {
            dt = new DataTable();
            lblMessage.Text = "Error: Record could not be retrieved.";
            lblMessage.Visible = true;
            PanelMessage.Visible = true;
        }

        return dt;
    }

    public string searchWhere(string text, string original)
    {
        string where = "";

        if (text == original || text == "")
        {
            where += "";
        }
        else
        {
            if (count > 0)
            {
                where += " AND ";
            }

            else
            {
                where += " where ";
            }

            count++;
            where += " " + original + " = '" + text.ToUpper() + "' ";
        }
        return where;
    }

    public string searchWhere(string text, string original, string databaseName)
    {
        string where = "";

        if (text == original || text == "")
        {
            where += "";
        }
        else
        {
            if (count > 0)
            {
                where += " AND ";
            }

            else
            {
                where += " where ";
            }

            count++;
            where += " " + original + " = '" + text.ToUpper() + "' ";
        }
        return where;
    }


    public void addDataTable()
    {
        try
        {
            count = 0;
            string sql = "Insert into " + table;
            string records = "(id, model, year, color, engine, mpg, handling, controls, safety, interior, "
                        + "audio, convenience, maintprogram, warranty, package, orderstatus, delivered, lastmaint, nextmaint, amountofmaint, customer) ";
            string fields = "";

            fields += addFields(txtModel.Text, "Model");
            fields += addFields(txtYear.Text, "Year");
            fields += addFields(txtColor.Text, "Color");
            fields += addFields(txtEngine.Text, "Engine");
            fields += addFields(txtMPG.Text, "MPG");
            fields += addFields(txtInterior.Text, "Interior");
            fields += addFields(txtHandling.Text, "Handling");
            fields += addFields(txtControls.Text, "Controls");
            fields += addFields(txtSafety.Text, "Safety");
            fields += addFields(txtAudio.Text, "Audio");
            fields += addFields(txtConvenience.Text, "Convenience");
            fields += addFields(txtMaintenance.Text, "Maintenance");
            fields += addFields(txtWarranty.Text, "Warranty");
            fields += addFields(txtPackage.Text, "Package");
            fields += addFields(txtCustomer.Text, "Customer");
            fields += addFields(txtStatus.Text, "Status");
            fields += addFields(txtDelivered.Text, "Delivered");
            fields += addFields(txtNumberMaint.Text, "Number of Maint.");
            fields += addFields(txtNextMaint.Text, "Next Maint.");
            fields += addFields(txtLastMaint.Text, "Last Maint.");


            SQLiteConnection connection = new SQLiteConnection("Data Source=C:\\Users\\Andres\\Documents\\Visual Studio 2015\\Projects\\cen4020electra-master\\cardb.db;Version=3;");
            connection.Open();
            sql += records + "values(NULL" + fields + ")";
            SQLiteCommand cmd = new SQLiteCommand(sql, connection);
            cmd.ExecuteNonQuery();
            connection.Close();

            lblMessage.Text = "Record was added successfully.";
            lblMessage.Visible = true;
            PanelMessage.Visible = true;
        }

        catch
        {
            lblMessage.Text = "Error: Record could not be added.";
            lblMessage.Visible = true;
            PanelMessage.Visible = true;
        }
    }

    public string addFields(string text, string original)
    {
        string fields = ", ";

        if (text == original || text == "")
        {
            fields += "NULL";
        }
        else
        {
            count++;
            fields += "'" + text.ToUpper() + "'";
        }
        return fields;
    }


    public void updateDataTable()
    {
        try
        {
            count = 0;
            string fields = "";

            fields += updateFields(txtModel.Text, "Model");
            fields += updateFields(txtYear.Text, "Year");
            fields += updateFields(txtColor.Text, "Color");
            fields += updateFields(txtEngine.Text, "Engine");
            fields += updateFields(txtMPG.Text, "MPG");
            fields += updateFields(txtInterior.Text, "Interior");
            fields += updateFields(txtHandling.Text, "Handling");
            fields += updateFields(txtControls.Text, "Controls");
            fields += updateFields(txtSafety.Text, "Safety");
            fields += updateFields(txtAudio.Text, "Audio");
            fields += updateFields(txtConvenience.Text, "Convenience");
            fields += updateFields(txtMaintenance.Text, "Maintenance", "maintprogram");
            fields += updateFields(txtWarranty.Text, "Warranty");
            fields += updateFields(txtPackage.Text, "Package");
            fields += updateFields(txtCustomer.Text, "Customer");
            fields += updateFields(txtStatus.Text, "Status", "orderstatus");
            fields += updateFields(txtDelivered.Text, "Delivered");
            fields += updateFields(txtNumberMaint.Text, "Number of Maint.", "amountofmaint");
            fields += updateFields(txtNextMaint.Text, "Next Maint.", "nextmaint");
            fields += updateFields(txtLastMaint.Text, "Last Maint.", "lastmaint");

            SQLiteConnection connection = new SQLiteConnection("Data Source=C:\\Users\\Andres\\Documents\\Visual Studio 2015\\Projects\\cen4020electra-master\\cardb.db;Version=3;");
            connection.Open();
            string sql = "Update " + table + " set " + fields + " where id = '" + txtID.Text + "'; SELECT ROW_COUNT();";
            SQLiteCommand cmd = new SQLiteCommand(sql, connection);
            int rowChanged = cmd.ExecuteNonQuery();
            connection.Close();

            if (rowChanged > 0)
            {
                lblMessage.Text = "Record was updated successfully.";
                lblMessage.Visible = true;
                PanelMessage.Visible = true;
            }

            else
            {
                lblMessage.Text = "No such record.";
                lblMessage.Visible = true;
                PanelMessage.Visible = true;
            }
        }

        catch
        {
            lblMessage.Text = "Error: Record could not be updated.";
            lblMessage.Visible = true;
            PanelMessage.Visible = true;
        }
    }

    public string updateFields(string text, string original)
    {
        string fields = "";

        if (text == original || text == "")
        {
            fields += "";
        }
        else
        {
            if (count > 0)
            {
                fields += ", ";
            }
            count++;
            fields += " " + original + " = '" + text.ToUpper() + "' ";
        }
        return fields;
    }

    public string updateFields(string text, string original, string databaseName)
    {
        string fields = "";

        if (text == original || text == "")
        {
            fields += "";
        }
        else
        {
            if (count > 0)
            {
                fields += ", ";
            }
            count++;
            fields += " " + databaseName + " = '" + text.ToUpper() + "' ";
        }
        return fields;
    }


    public void deleteDataTable()
    {
        try
        {
            count = 0;
            string where = "";

            where += deleteWhere(txtID.Text, "ID");
            where += deleteWhere(txtModel.Text, "Model");
            where += deleteWhere(txtYear.Text, "Year");
            where += deleteWhere(txtColor.Text, "Color");
            where += deleteWhere(txtEngine.Text, "Engine");
            where += deleteWhere(txtMPG.Text, "MPG");
            where += deleteWhere(txtInterior.Text, "Interior");
            where += deleteWhere(txtHandling.Text, "Handling");
            where += deleteWhere(txtControls.Text, "Controls");
            where += deleteWhere(txtSafety.Text, "Safety");
            where += deleteWhere(txtAudio.Text, "Audio");
            where += deleteWhere(txtConvenience.Text, "Convenience");
            where += deleteWhere(txtMaintenance.Text, "Maintenance", "maintprogram");
            where += deleteWhere(txtWarranty.Text, "Warranty");
            where += deleteWhere(txtPackage.Text, "Package");
            where += deleteWhere(txtCustomer.Text, "Customer");
            where += deleteWhere(txtStatus.Text, "Status", "orderstatus");
            where += deleteWhere(txtDelivered.Text, "Delivered");
            where += deleteWhere(txtNumberMaint.Text, "Number of Maint.", "amountofmaint");
            where += deleteWhere(txtNextMaint.Text, "Next Maint.", "nextmaint");
            where += deleteWhere(txtLastMaint.Text, "Last Maint.", "lastmaint");

            SQLiteConnection connection = new SQLiteConnection("Data Source=C:\\Users\\Andres\\Documents\\Visual Studio 2015\\Projects\\cen4020electra-master\\cardb.db;Version=3;");
            connection.Open();
            string sql = "Delete from " + table + " where " + where;
            SQLiteCommand cmd = new SQLiteCommand(sql, connection);
            cmd.ExecuteNonQuery();
            connection.Close();

            lblMessage.Text = "Record was deleted successfully.";
            lblMessage.Visible = true;
            PanelMessage.Visible = true;
        }

        catch
        {
            lblMessage.Text = "Error: Record could not be deleted.";
            lblMessage.Visible = true;
            PanelMessage.Visible = true;
        }
    }

    public string deleteWhere(string text, string original)
    {
        string where = "";

        if (text == original || text == "")
        {
            where += "";
        }
        else
        {
            if (count > 0)
            {
                where += " AND ";
            }
            count++;
            where += " " + original + " = '" + text.ToUpper() + "' ";
        }
        return where;
    }

    public string deleteWhere(string text, string original, string databaseName)
    {
        string where = "";

        if (text == original || text == "")
        {
            where += "";
        }
        else
        {
            if (count > 0)
            {
                where += " AND ";
            }
            count++;
            where += " " + databaseName + " = '" + text.ToUpper() + "' ";
        }
        return where;
    }


    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        LoadGrid();
    }
}
